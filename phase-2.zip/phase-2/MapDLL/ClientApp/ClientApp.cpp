// Author: Jeff Ngeama
// Course: CIS 687
//Syracuse University
//Project 2
//Start Date: 04/22/22
//Last Updated Date: 05/12/22

#include <iostream>
#include <iostream>
#include <windows.h>
#include <string>

using namespace std;

typedef string (*funcmap)(string,string,string,string,string,string,string,string);

int main()
{
	HINSTANCE hDLL;
	funcmap map;
	funcmap map_export;
	const wchar_t* libName = L"MapDLL";
	//load the library and assign the handler for the handle to hDLL
	hDLL = LoadLibraryEx(libName, NULL, NULL);   // Handle to DLL
	// proceed only if the handler to hDLL is not NULL
	if (hDLL != NULL) {
		map = (funcmap)GetProcAddress(hDLL, "map");
		if (map != NULL) {
			// define the three directories
			string _infiledirectory = "C:\\Users\\ndung\\source\\repos\\MapDLL\\Input_files";
			string _outfiledirectory = "C:\\Users\\ndung\\source\\repos\\MapDLL\\Output_files";
			string _intermediatefiledirectory = "C:\\Users\\ndung\\source\\repos\\MapDLL\\Intermediate_files";
			//define the 3 file names
			string _infilename = "infilename1.txt";
			string _outfilename = "outfilename1.txt";
			string _intermediatefilename = "intermediatefilename1.txt";
			// the key is name of the intermediate file 
			string key = _intermediatefilename;
			//the value is the sentence we are tokenizing
			string value = "its a sentence Yahoo! Finance is a media property that is part of the Yahoo! network. It provides financial news, data and commentary including stock quotes, press releases, financial reports, and original content. It also offers some online tools for personal finance management.";
			string result = "";
			//result calls the result of the map function
			//The map function takes the three directory names,the three file names, the key and the value
			result = map(_infiledirectory, _outfiledirectory, _intermediatefiledirectory, _infilename, _outfilename, _intermediatefilename, key, value);
			//print the result of the map function to the screen
			cout << result << endl;
		}
		else
		{
			// if the loading of map function was not successful then write the error msg to the screen
			cout << "Did not load map function correctly." << endl;
		}
		//free the handler to the library
		FreeLibrary(hDLL);
	}
	else {
		// if the DLL library did not load successfully print the error msg
		cout << "Library load failed!" << endl;
	}

	//std::cin.get();
	return 0;
}
